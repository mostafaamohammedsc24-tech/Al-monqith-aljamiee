/**
 * Wayl Checkout Admin Scripts
 */
(function($) {
	'use strict';

	$(document).ready(function() {
		// Wait for refund dialog to be created
		$(document).on('click', '.refund-items', function() {
			setTimeout(function() {
				// Disable refund amount input and set to full amount
				var refundAmountField = $('#refund_amount');
				if (refundAmountField.length) {
					var fullAmount = refundAmountField.data('max');
					refundAmountField.val(fullAmount).prop('readonly', true).css('background-color', '#f0f0f0');
					
					// Add notice about full refund
					if (!$('#waylchp-full-refund-notice').length) {
						var refundNotice = '<div id="waylchp-full-refund-notice" style="margin-top: 5px; padding: 8px; background: #fff3cd; border-left: 4px solid #ffc107; color: #856404;"><strong>' + waylCheckoutAdmin.refundLabel + '</strong> ' + waylCheckoutAdmin.refundMessage + '</div>';
						refundAmountField.after(refundNotice);
					}
				}

				// Limit refund reason to 100 characters
				var refundReasonField = $('#refund_reason');
				if (refundReasonField.length) {
					var maxLength = 100;
					var currentLength = refundReasonField.val().length;
					
					// Add character counter
					if (!$('#waylchp-refund-reason-counter').length) {
						var counter = '<div id="waylchp-refund-reason-counter" style="margin-top: 5px; font-size: 12px; color: #666;"><span id="waylchp-char-count">' + currentLength + '</span> / ' + maxLength + ' ' + waylCheckoutAdmin.charactersLabel + '</div>';
						refundReasonField.after(counter);
					}
					
					// Update counter on input
					refundReasonField.on('input', function() {
						var length = $(this).val().length;
						$('#waylchp-char-count').text(length);
						
						if (length > maxLength) {
							$(this).val($(this).val().substring(0, maxLength));
							$('#waylchp-char-count').text(maxLength).css('color', '#dc3545');
							alert(waylCheckoutAdmin.refundReasonMaxLength);
						} else if (length > maxLength * 0.9) {
							$('#waylchp-char-count').css('color', '#ffc107');
						} else {
							$('#waylchp-char-count').css('color', '#666');
						}
					});
					
					// Add maxlength attribute
					refundReasonField.attr('maxlength', maxLength);
					
					// Add placeholder
					refundReasonField.attr('placeholder', waylCheckoutAdmin.refundReasonPlaceholder);
				}
			}, 100);
		});
	});
})(jQuery);

