<?php
/**
 * Wayl Logger
 *
 * No-op placeholder. Logging is not used.
 *
 * @package Wayl_Checkout
 * @since 1.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class WaylCHP_Logger
 */
class WaylCHP_Logger {

	/**
	 * Initialize (no-op)
	 *
	 * @return void
	 */
	public static function init() {
		// No-op.
	}

	/**
	 * Log (no-op)
	 *
	 * @param string $message Log message
	 * @param string $level   Log level
	 * @param bool   $force   Force logging
	 * @return void
	 */
	public static function log( $message, $level = 'info', $force = false ) {
		// No-op.
	}

	/**
	 * Info (no-op)
	 *
	 * @param string $message Log message
	 * @param bool   $force  Force logging
	 * @return void
	 */
	public static function info( $message, $force = false ) {
		// No-op.
	}

	/**
	 * Error (no-op)
	 *
	 * @param string $message Log message
	 * @param bool   $force  Force logging
	 * @return void
	 */
	public static function error( $message, $force = false ) {
		// No-op.
	}

	/**
	 * Warning (no-op)
	 *
	 * @param string $message Log message
	 * @param bool   $force  Force logging
	 * @return void
	 */
	public static function warning( $message, $force = false ) {
		// No-op.
	}

	/**
	 * Debug (no-op)
	 *
	 * @param string $message Log message
	 * @param bool   $force  Force logging
	 * @return void
	 */
	public static function debug( $message, $force = false ) {
		// No-op.
	}
}
