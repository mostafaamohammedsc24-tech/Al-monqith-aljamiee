<?php
/**
 * Wayl API Client
 *
 * Handles communication with the Wayl API.
 *
 * @package Wayl_Checkout
 * @since 1.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class WaylCHP_API
 */
class WaylCHP_API {
	/**
	 * API base URL
	 *
	 * @var string
	 */
	private $api_base = 'https://api.thewayl.com/api/v1';

	/**
	 * API key
	 *
	 * @var string
	 */
	private $api_key;

	/**
	 * Constructor
	 *
	 * @param string|null $api_key Optional API key, otherwise retrieved from options
	 */
	public function __construct( $api_key = null ) {
		// Use provided API key or get from options
		$this->api_key = $api_key ?: get_option( 'waylchp_api_key', '' );
	}

	/**
	 * Create a Wayl checkout link
	 *
	 * @param array $payload
	 * @return array|false Decoded response or false on failure
	 */
	public function create_checkout_link( array $payload ) {
		if ( empty( $this->api_key ) ) {
			return false;
		}

		$url = $this->api_base . '/links';

		$args = array(
			'headers'     => array(
				'Content-Type'           => 'application/json',
				'X-WAYL-AUTHENTICATION' => $this->api_key,
			),
			'body'        => wp_json_encode( $payload ),
			'timeout'     => 30,
			'data_format' => 'body',
		);

		$response = wp_remote_post( $url, $args );

		if ( is_wp_error( $response ) ) {
			return false;
		}

		$status_code = wp_remote_retrieve_response_code( $response );
		$body        = wp_remote_retrieve_body( $response );

		if ( $status_code !== 200 && $status_code !== 201 ) {
			return false;
		}

		$data = json_decode( $body, true );

		if ( json_last_error() !== JSON_ERROR_NONE ) {
			return false;
		}

		return $data;
	}

	/**
	 * Get available payment channels from Wayl API
	 *
	 * @return array|false Array of channels or false on failure
	 */
	public function get_payment_channels() {
		if ( empty( $this->api_key ) ) {
			return false;
		}

		$url = $this->api_base . '/channels';

		$args = array(
			'headers' => array(
				'X-WAYL-AUTHENTICATION' => $this->api_key,
			),
			'timeout' => 15,
		);

		$response = wp_remote_get( $url, $args );

		if ( is_wp_error( $response ) ) {
			return false;
		}

		$status_code = wp_remote_retrieve_response_code( $response );
		$body       = wp_remote_retrieve_body( $response );

		if ( $status_code !== 200 ) {
			return false;
		}

		$data = json_decode( $body, true );

		if ( json_last_error() !== JSON_ERROR_NONE ) {
			return false;
		}

		if ( isset( $data['data'] ) && is_array( $data['data'] ) ) {
			return $data['data'];
		}

		return false;
	}

	/**
	 * Process refund via Wayl API
	 *
	 * @param string $reference_id Original payment reference ID (sent to Wayl during payment)
	 * @param int    $amount Refund amount in IQD (always the full order amount)
	 * @param string $reason Refund reason (provided by merchant)
	 * @return array|false Decoded response or false on failure
	 */
	public function process_refund( $reference_id, $amount, $reason = '' ) {
		if ( empty( $this->api_key ) ) {
			return false;
		}

		$url = $this->api_base . '/refunds';

		$payload = array(
			'referenceId' => sanitize_text_field( $reference_id ),
			'amount'      => intval( $amount ),
			'reason'      => sanitize_text_field( $reason ),
		);

		$args = array(
			'headers'     => array(
				'Content-Type'           => 'application/json',
				'X-WAYL-AUTHENTICATION' => $this->api_key,
			),
			'body'        => wp_json_encode( $payload ),
			'timeout'     => 30,
			'data_format' => 'body',
		);

		$response = wp_remote_post( $url, $args );

		if ( is_wp_error( $response ) ) {
			return false;
		}

		$status_code = wp_remote_retrieve_response_code( $response );
		$body        = wp_remote_retrieve_body( $response );

		if ( $status_code !== 200 && $status_code !== 201 ) {
			return false;
		}

		$data = json_decode( $body, true );

		if ( json_last_error() !== JSON_ERROR_NONE ) {
			return false;
		}

		return $data;
	}

	/**
	 * Verify webhook signature
	 *
	 * @param string $payload
	 * @param string $signature
	 * @param string $secret
	 * @return bool
	 */
	public static function verify_webhook_signature( $payload, $signature, $secret ) {
		$expected_signature = hash_hmac( 'sha256', $payload, $secret );
		return hash_equals( $expected_signature, $signature );
	}
}

