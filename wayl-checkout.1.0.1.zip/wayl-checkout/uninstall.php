<?php
/**
 * Uninstall script for Wayl Checkout Payment Plugin
 *
 * This file is executed when the plugin is uninstalled.
 * It removes all plugin data from the database and filesystem.
 *
 * @package Wayl_Checkout
 * @since 1.2.0
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// Check user capabilities
if ( ! current_user_can( 'activate_plugins' ) ) {
	return;
}

// Delete plugin options
$waylchp_options_to_delete = array(
	'waylchp_webhook_secret',
	'waylchp_api_key',
	'waylchp_activation_email_sent',
);

foreach ( $waylchp_options_to_delete as $waylchp_option ) {
	delete_option( $waylchp_option );
}

// Delete WooCommerce payment gateway settings
$waylchp_gateway_settings = get_option( 'woocommerce_wayl_settings', array() );
if ( ! empty( $waylchp_gateway_settings ) ) {
	delete_option( 'woocommerce_wayl_settings' );
}

// Delete transients
delete_transient( 'waylchp_payment_channels' );

// Clear any cached data
wp_cache_flush();
