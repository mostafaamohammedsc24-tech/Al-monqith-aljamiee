=== Wayl Checkout ===
Contributors: wayl
Tags: payment, checkout, wayl, woocommerce, iraq
Requires at least: 5.0
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 1.0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
WC requires at least: 5.0
WC tested up to: 8.5

Enable Wayl Checkout payments in your WooCommerce store. Accept online payments via Visa/MasterCard, ZainCash, FIB, and FastPay.

== Description ==

**English:**  
Wayl Checkout allows WooCommerce merchants to accept online payments securely via Visa, MasterCard, ZainCash, FIB, and FastPay. Licensed by the Central Bank of Iraq and PCI DSS compliant, Wayl ensures your store never handles card data. Funds are settled weekly to your bank or ZainCash account. Supports both IQD and USD, with refunds processed directly from WooCommerce orders.

**العربية:**  
وايل تشيك أوت تتيح للتجار في WooCommerce قبول المدفوعات الإلكترونية بأمان عبر فيزا، ماستركارد، زين كاش، البنك العراقي الأول، وفاست باي. مرخصة من البنك المركزي العراقي ومتوافقة مع PCI DSS، لضمان عدم تعامل متجرك مع بيانات البطاقات. يتم تحويل الأرباح أسبوعياً إلى الحساب البنكي أو محفظة زين كاش. يدعم الدينار العراقي والدولار الأمريكي، مع إمكانية استرداد المبالغ مباشرة من طلبات WooCommerce.

---

## Payment Methods / وسائل الدفع

* Visa / MasterCard (local and international)
* ZainCash
* FIB (First Iraqi Bank)
* FastPay

One checkout flow. No extra plugins required.

---

## Key Features / الميزات

* IQD & USD support
* PCI DSS compliant — secure payment processing
* Real-time order status updates in WooCommerce
* Refunds handled directly from WooCommerce
* Simple setup with API credentials — no coding required
* Arabic & English payment pages

---

## Frequently Asked Questions / الأسئلة الشائعة

**English**  
**Q:** Can I accept payments from outside Iraq?  
**A:** Yes, international Visa and MasterCard payments are supported.  

**Q:** How do I receive my funds?  
**A:** Funds are settled weekly to your registered bank account or ZainCash wallet.  

**Q:** Is there a monthly subscription?  
**A:** No, the plugin is free; only transaction fees apply.  

**Q:** Can I issue refunds?  
**A:** Yes, refunds can be processed via WooCommerce orders.

**العربية**  
**س:** هل يمكن قبول المدفوعات من خارج العراق؟  
**ج:** نعم، تدعم المنصة بطاقات فيزا وماستر كارد الدولية.  

**س:** كيف أستلم أرباحي؟  
**ج:** يتم تحويل الأرباح أسبوعياً إلى الحساب البنكي أو محفظة زين كاش المسجلة.  

**س:** هل هناك اشتراك شهري؟  
**ج:** لا، الإضافة مجانية، ويتم تطبيق الرسوم فقط على كل عملية دفع ناجحة.  

**س:** هل يمكن عمل استرداد؟  
**ج:** نعم، يمكن تنفيذ الاسترداد مباشرة من شاشة طلبات WooCommerce.

---

## Installation / التثبيت

1. Upload the plugin files to `/wp-content/plugins/wayl-checkout/` or install via WordPress admin.  
2. Activate the plugin under Plugins > Installed Plugins.  
3. Go to WooCommerce > Settings > Payments > Wayl and enter your API Key.  
4. Optionally, choose your language (Arabic / English) and currency mode (IQD / USD).  
5. Save settings and test a transaction in test mode if available.

---

## Support / الدعم

* **Email:** jisr@wayl.io  
* **WhatsApp:** +964 775 227 7781  
* **Website:** https://www.wayl.io  
* **Dashboard:** https://dashboard.thewayl.com  

---

## Requirements / المتطلبات

* WordPress 5.0+  
* WooCommerce 5.0+  
* PHP 7.4+  
* SSL certificate for live payments  

== Changelog ==

= 1.0.1 =
* Always require webhook signature verification (reject if secret or signature header is missing)
* Verify against the official `x-wayl-signature-256` header (HMAC-SHA256 of raw body)
* Update support email to jisr@wayl.io

= 1.0.0 =
* Initial production release for WordPress.org

== Upgrade Notice ==

= 1.0.1 =
Security hardening for webhook signature verification. Recommended for all stores.